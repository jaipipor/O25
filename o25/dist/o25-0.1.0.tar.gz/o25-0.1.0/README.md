# O25 - Python Port

## Installation
```bash
conda create -n o25 python=3.9 numpy scipy matplotlib
conda activate o25

**Inquiries to**: jaime.pitarch@cnr.it.
